export class userAuthDto {
email:string;
password:string;
}
