

export type  usertype = {
    username:string;
    email:string;
    password:string;
}